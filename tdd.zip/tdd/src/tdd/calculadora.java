package tdd;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.geom.CubicCurve2D.Double;
import java.util.Scanner;

import org.junit.jupiter.api.Test;


class calculadora {
	double n1;
    double n2;
    String  operacao = "";
// codigo do segundo semestre 
	@Test
	public void test() {
	
			
			Scanner entrada = new Scanner(System.in);
			
			System.out.print("Digite a opera��o desejada (+, -, *, /): ");
			operacao = entrada.nextLine();
			
			System.out.println("Digite um valor: ");
			n1 = Integer.parseInt(entrada.nextLine());
			
			System.out.println("Digite um valor: ");
			n2 = Integer.parseInt(entrada.next());
			
			int controle = 0;
			if(operacao.equals("+")) {
				System.out.println("O resultado da Soma �: " + (n1+n2));
				controle ++;			
			}
			
			if(operacao.equals("-")) {
				System.out.println("O resultado da subtra��o �: " +(n1 - n2));
				controle++;		
			}
			
			if(operacao.equals("*")) {
				System.out.println("O resultado da multiplica��o �: " +(n1 * n2));
				controle++;			
			}
			
			if(operacao.equals("/")) {
				System.out.println("O resultado da divis�o �: " +(n1 / n2));
				controle++;			
			}
			
					
 }

public double soma() {
	return n1+n2;
	
}
}
